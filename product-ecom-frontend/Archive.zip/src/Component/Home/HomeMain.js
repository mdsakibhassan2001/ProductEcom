import React from 'react'
import MainSlider from './MainSlider'
import Category from './Category'
import BestSellingProduct from './BestSellingProduct'
import TwoBanner from './TwoBanner'

export default function HomeMain() {
  return (
    <>
        <MainSlider/>
        <Category/>
        <BestSellingProduct/>
        <TwoBanner/>
    </>
  )
}
